@POST
	@Produces(MediaType.APPLICATION_JSON)
	public Country addCountry(@FormParam("txtId") int txtId,
			@FormParam("txtName") String txtName,
			@FormParam("txtPopulation") long txtPopulation) {
		Country country = new Country();
		country.setCountryId(txtId);
		country.setCountryName(txtName);
		country.setPopulation(txtPopulation);
		return countryService.addCountry(country);
	}

	/**
	 * Method to delete a country,supporting HTTP POST method, here we are using
	 * POST to support delete produces Media type of JSON
	 * 
	 * @param id
	 * @return Country
	 */
	@POST
	@Path("/delete")
	@Produces(MediaType.APPLICATION_JSON)
	public Country deleteCountry(@FormParam("txtId") int id) {
		Country country = countryService.deleteCountry(id);
		// if valid country Id is existing then country gets deleted; otherwise
		// returning a JSON object with default (null) values
		if (country != null) {
			return country;
		} else {
			return new Country();
		}

	}